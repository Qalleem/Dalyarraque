# QVLLEN BOOTH v5 — Entegrasyon

## Tek Komutla Deploy (local terminalden)

Repo'nun `main` branch'inde:

```bash
# 1. İndirdiğin paketi repo root'una çıkar
#    (index.html + .github/workflows/static.yml + .nojekyll)

# 2. Çakışan eski workflow'ları sil
git rm .github/workflows/jekyll-gh-pages.yml
git rm .github/workflows/nextjs.yml

# 3. Commit + push
git add index.html .github/workflows/static.yml .nojekyll
git commit -m "v5: production engineering pass (HPF 110, TPDF, limiter, IDB)"
git push origin main
```

2-3 dk içinde `qalleem.github.io/Dalyarraque/` v5'e geçer.

## GitHub UI ile (terminal kullanmak istemezsen)

1. Repo sayfasına git → `index.html` dosyasına tıkla → kalem (Edit) → eski içeriği sil, v5'i yapıştır → Commit
2. `.github/workflows/` klasörüne git → `jekyll-gh-pages.yml` aç → kalem ikonu değil, sağda 🗑 (Delete) → Commit
3. Aynı şekilde `nextjs.yml` → Delete → Commit
4. `static.yml` zaten var, dokunma (ama içeriği paketteki ile eşleşiyorsa güncel)

## Deploy Doğrulama

Push'tan sonra:

1. Repo → **Actions** sekmesi → en üstteki workflow run yeşil ✓ olmalı
2. Repo → **Settings → Pages** → "Your site is live at ..." yazmalı
3. `qalleem.github.io/Dalyarraque/` → tarayıcı cache'i temizle (`Ctrl+Shift+R` / iOS'ta Safari > Clear History)
4. Header'da **"QB v5"** yazıyorsa entegrasyon tamam

## Önemli Not — CDN Cache

GitHub Pages CDN eski versiyonu 10 dk kadar tutabilir. Canlıda hâlâ v4 görüyorsan:
- Mobilde: Chrome > site ayarları > cookies/cache temizle
- Masaüstü: DevTools aç (F12) → Network tab → "Disable cache" işaretle, refresh

## Version Kontrol

Yeni çalışan domain'de F12 console'u aç, şunu yaz:
```js
document.querySelector('.h-logo').textContent
```
- `"QB v4"` → eski versiyon hâlâ cache'te
- `"QB v5"` → entegrasyon başarılı

## Neden 3 workflow sorunluydu?

Üç workflow da `push: main` tetiği + `pages` concurrency group'u kullanıyordu.
- `jekyll-gh-pages.yml` → Jekyll build çalıştırıyor (bu repo static HTML, gereksiz)
- `nextjs.yml` → Next.js arıyor (bu repo Next değil, fail eder)
- `static.yml` → Doğru olan

Üçü paralel queue'da birbirini ezebiliyor. Artık tek workflow = tek deploy = stabil.
